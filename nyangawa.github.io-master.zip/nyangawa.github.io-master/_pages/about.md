---
layout: single
title: About me
author_profile: true
permalink: /about/
---

GitHub [@nyangawa](https://github.com/nyangawa)

Twitter [@nyan_gawa](https://twitter.com/nyan_gawa)

Thanks to [Jekyll](https://jekyllrb.com/) for making blog easy and elegant.

Thanks to [@mmistakes](https://github.com/mmistakes/minimal-mistakes) for creating a fantastic theme.

Collections:

+ CVE-2018-14364 CVSS 9.8
+ CVE-2018-18649 CVSS 9.8
+ CVE-2018-19856 CVSS 7.5
+ CVE-2018-19571 CVSS 7.7
+ CVE-2018-20144 CVSS 7.5
+ CVE-2018-20229 CVSS 7.5
+ CVE-2018-20499 CVSS 7.2
+ CVE-2019-6240 CVSS 7.5
+ CVE-2019-6792 CVSS 5.3
+ CVE-2019-8324 CVSS 8.8
+ CVE-2019-9221 CVSS 5.5
+ CVE-2019-12430 CVSS 8.8
+ CVE-2019-12441 CVSS 7.5
+ CVE-2019-12443 CVSS 9.8
+ CVE-2019-12445 CVSS 5.4
+ CVE-2019-19088 CVSS 9.8
+ CVE-2019-19309 CVSS 4.3
+ CVE-2019-19628 CVSS 9.8
+ CVE-2020-6832 CVSS 5.3
+ CVE-2020-7966 CVSS 7.5
+ CVE-2020-10086 CVSS 5.3
+ CVE-2020-10953 CVSS 7.5
+ CVE-2020-12448 CVSS 5.3
+ CVE-2021-22201 CVSS 9.6
